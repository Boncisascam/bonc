Bonkcoin Core 1.0.1
=====================

Intro
-----
ist ein kostenloses und vollständig dezentralisiertes Open-Source-Peer-to-Peer-Electronic-Cash-System,
ohne die Notwendigkeit eines zentralen Servers oder vertrauenswürdiger Parteien.
Benutzer halten die Krypto-Schlüssel zu ihrem eigenen Geld und führen direkte Transaktionen miteinander durch, 
mit Hilfe eines P2P-Netzwerks, um doppelte Ausgaben zu überprüfen.


Setup
-----
Entpacken Sie die Dateien in ein Verzeichnis oder installieren Sie per Installer und führen die bonkcoin-qt.exe aus.
Bonkcoin Core ist der ursprüngliche Bonkcoin-Client und bildet das Rückgrat des Netzwerks. 
Es lädt jedoch die gesamte Geschichte der Bonkcoin-Transaktionen herunter und speichert sie. 
Abhängig von der Geschwindigkeit deines Computers und der Netzwerkverbindung kann der Synchronisierungsprozess von einigen Stunden bis zu einem Tag oder länger dauern.
Beim ersten Start wird automatisch eine Wallet erstellt. Sichern Sie Ihre Wallet mit einer Verschlüsselung (Passwort), die Sie sich merken können!


Für allgemeine Informationen über Bonkcoin Core lesen Sie im Dogecoin-Wiki nach, unter: https://www.reddit.com/r/dogecoin/wiki/dogecoincoreguide
Da Bonkcoin eine Abspaltung/Fork von Dogecoin ist, werden die meisten Informationen dort auch auf Bonkcoin zutreffen.
