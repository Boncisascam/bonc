## Bonkcoin Core 1.3.1 Release Notes

This is a new minor release which includes improvements Various security fixes releases.

All users on all platforms, are **strongly recommended** to upgrade.

#### Technical Changes
* Various security fixes
* Resolving test-build error (currently disable it for now), will eventually fix it in the next release
* Add halving change to block 50k from block 100k into protocol, will later kick the old node out in the next release
* New checkpoint

#### Design Changes
* Add German, Persian, French, Portuguese, Vietnamese, Chinese and Japanese translations for README.md

#### Other changes
* We have merged our pepe + doge history, this is how transparency we are

#### Improve dialogues
* Minor UI update

#### Credits
* Mamafunny
* Everyone on Pepeteam
* Denz8ty
