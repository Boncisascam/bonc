## Bonkcoin Core 1.4.0 Release Notes

This is a new MAJOR release.

All users on all platforms, **MUST** upgrade.

#### Technical Changes

* Add devfee activate on block 100,500 (around two weeks from now, should be enough time for pools and exchange to upgrade)
* Bump min_peer to 70017
* Bump version on qt and docs to 1.4.0 (since this is a fork)

#### Credits
* Mamafunny