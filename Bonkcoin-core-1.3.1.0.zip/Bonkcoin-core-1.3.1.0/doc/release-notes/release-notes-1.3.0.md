## Bonkcoin Core 1.3.1 Release Notes

Tokenomics change . All users are **strongly recommended** to upgrade.

#### Credits

* mamafunny