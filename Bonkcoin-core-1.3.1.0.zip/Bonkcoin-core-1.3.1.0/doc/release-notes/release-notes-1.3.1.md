## Bonkcoin Core 1.3.1 Release Notes

Minior update

- Fixed problem when compiling
- Added another checkpoint
- Improved dialogues
- Improved typo in UI

All users are **strongly recommended** to upgrade.

#### Credits

* mamafunny
* denz8ty