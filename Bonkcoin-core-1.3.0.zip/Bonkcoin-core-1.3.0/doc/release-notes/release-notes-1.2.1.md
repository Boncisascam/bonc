## Bonkcoin Core 1.2.1 Release Notes

This is a new minor version release that added new checkpoint. 

All users are **strongly recommended** to upgrade.

#### Technical Changes

* logo changed

#### Credits

* mamafunny