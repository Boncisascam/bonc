## Bonkcoin Core 1.2 Release Notes

This is a new minor release which includes improvements from recent Dogecoin releases. All users are **strongly recommended** to upgrade.

#### Technical Changes

* Fixed wrong explorer in windows qt
* Fixed typo

#### Design Changes

* Update P logo for "About Bonkcoin Core" in the help menu

#### Credits

* mamafunny